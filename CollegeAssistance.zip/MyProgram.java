import java.util.*;
public class MyProgram extends ConsoleProgram
{
    public ArrayList<String> colleges = new ArrayList<String>();
    public void run()
    {
        colleges.add("Missouri S&T");
        colleges.add("Missouri State University");
        colleges.add("Southeast Missouri State");
        colleges.add("University of Hard Knocks");
        for(int i=0;i<colleges.size();i++)
        {
            System.out.println(colleges.get(i));
        }
    }
}