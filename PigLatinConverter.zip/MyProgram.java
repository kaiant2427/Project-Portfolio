public class MyProgram extends ConsoleProgram
{
    public void run()
    {
        int wL=0;
        String lL="";
        String nS="";
        String s=readLine("Please enter your word to be converted: ");
        wL=s.length();
        lL=s.substring(wL-1);
        nS=s.substring(0,(wL-1));
        String end="a";
        System.out.println(lL+nS+end);
    }
}
