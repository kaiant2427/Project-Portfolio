public class MyProgram extends ConsoleProgram
{
    public void run()
    {
        int[] arr={1,3,4,5,7};
        int[] arr2={36466,4829,7190};
        System.out.println(sumArray(arr));
        System.out.println(sumArray(arr2));
    }
    public int sumArray(int[] arr)
    {
        int sum = 0;
        for(int i = 0; i < arr.length; i++)
        {
            sum += arr[i];
        }
        return sum;
    }
}