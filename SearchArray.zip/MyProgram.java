public class MyProgram extends ConsoleProgram
{
    public void run()
    {
        int[] arr={1,3,4,5,7};
        int[] arr2={364,482,719};
        System.out.println(searchArray(arr,4));
        System.out.println(searchArray(arr,2));
        System.out.println(searchArray(arr2,2));
        System.out.println(searchArray(arr2,482));
    }
    public int searchArray(int[] arr, int element)
    {
        int elem=element;
        int index=0;
        for(int i = 0; i < arr.length; i++)
        {
            if(arr[i]==elem)
            {
                index=i;
                return index;
            }
        }
        return -1;
    }
}